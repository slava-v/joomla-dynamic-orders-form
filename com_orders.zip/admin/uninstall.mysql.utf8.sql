SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

DROP TABLE `jos_orders_fields` ;
DROP TABLE `jos_orders_forms`  ;
DROP TABLE `jos_orders_inbox` ;
DROP TABLE `jos_orders_products` ;
